﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LatinTranslator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
     

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSinisterLeft_Click(object sender, EventArgs e)
        {
            lblResult.Text = "Left";
        }

        private void btnDexterRight_Click(object sender, EventArgs e)
        {
            lblResult.Text = "Right";
        }

        private void btnMediumCenter_Click(object sender, EventArgs e)
        {
            lblResult.Text = "Center";
        }
    }
}
